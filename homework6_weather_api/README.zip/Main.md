

```python
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from random import uniform
from config import api_key
import citipy.citipy as cit
import openweathermapy.core as owm
```


```python
# randonly get 500 set lat and lng combinations

lat_lng_list = []

for i in range(600):

    (x, y) = uniform(-90, 90), uniform(-180,180)
    
    lat_lng_list.append((x, y))
    
    
#lat_lng_list[0:3]
```




    [(51.784387587065254, -21.75486971018171),
     (66.8331762578949, -96.86241798056535),
     (-77.49542528074187, -54.154542755260195)]




```python
# get 500 cities 
city_list = []

for i in lat_lng_list:

    city_name = cit.nearest_city(i[0], i[1]).city_name
    city_list.append(city_name)

    
#len(city_list)
```

    ['dingle', 'thompson', 'ushuaia', 'ocampo', 'kodiak', 'konskie', 'georgetown', 'kuche', 'dossor', 'fukue', 'otradinskiy', 'rikitea', 'qaanaaq', 'faanui', 'mataura', 'jamestown', 'nardaran', 'tasiilaq', 'belushya guba', 'castro', 'bethel', 'ponta do sol', 'bluff', 'carnarvon', 'charters towers', 'avarua', 'gobabis', 'jamestown', 'lata', 'dudinka', 'thompson', 'almeirim', 'one hundred mile house', 'dalvik', 'tuatapere', 'hovd', 'rikitea', 'port-gentil', 'kapaa', 'soyo', 'narsaq', 'bredasdorp', 'saint-philippe', 'vaini', 'ushuaia', 'ribeira grande', 'hobart', 'amderma', 'albany', 'hobart', 'eureka', 'carnarvon', 'laguna', 'tumannyy', 'rikitea', 'kloulklubed', 'bluff', 'belushya guba', 'remedios', 'ushuaia', 'panzhihua', 'illoqqortoormiut', 'cape town', 'taolanaro', 'hobart', 'ribeira grande', 'makakilo city', 'nikolskoye', 'longyearbyen', 'zhezkazgan', 'chokurdakh', 'east london', 'mys shmidta', 'katsuura', 'bengkulu', 'kuching', 'hobart', 'pennsville', 'sitka', 'labytnangi', 'ponta do sol', 'rikitea', 'saint-philippe', 'buala', 'lazaro cardenas', 'nikolskoye', 'rikitea', 'danjiangkou', 'airai', 'zarate', 'qeshm', 'hamilton', 'bad neuenahr-ahrweiler', 'sorland', 'dukat', 'roald', 'mataura', 'mataura', 'mataura', 'rikitea', 'mataura', 'pitimbu', 'bambous virieux', 'inyonga', 'georgetown', 'sao jose da coroa grande', 'kapaa', 'zeya', 'port alfred', 'lorengau', 'belushya guba', 'port elizabeth', 'rikitea', 'hobart', 'norman wells', 'khumalag', 'longyearbyen', 'ushuaia', 'hamilton', 'albany', 'carnarvon', 'albany', 'ahipara', 'rikitea', 'tuktoyaktuk', 'ondorhaan', 'georgetown', 'matara', 'port blair', 'rikitea', 'lantawan', 'castro', 'busselton', 'punta arenas', 'matamoros', 'taolanaro', 'meulaboh', 'busselton', 'illoqqortoormiut', 'bredasdorp', 'longyearbyen', 'ushuaia', 'yellowknife', 'dodge city', 'juneau', 'baruun-urt', 'avarua', 'flinders', 'taolanaro', 'lebu', 'yeletskiy', 'rikitea', 'taolanaro', 'morant bay', 'nikolskoye', 'punta arenas', 'hasaki', 'punta arenas', 'ushuaia', 'maua', 'avarua', 'tuktoyaktuk', 'kamaishi', 'atuona', 'katherine', 'east london', 'teya', 'albany', 'rawson', 'nizhneyansk', 'puqi', 'seymchan', 'kruisfontein', 'puerto ayora', 'torbay', 'mount gambier', 'taoudenni', 'batagay', 'kadhan', 'fort nelson', 'gravdal', 'mys shmidta', 'hilo', 'atuona', 'constitucion', 'port alfred', 'thompson', 'rikitea', 'sangmelima', 'mount gambier', 'santa isabel do rio negro', 'mullaitivu', 'vaini', 'kapaa', 'evensk', 'pevek', 'nikolskoye', 'rio gallegos', 'mataura', 'elk plain', 'saint-philippe', 'mokhsogollokh', 'bethel', 'cayenne', 'rikitea', 'kapaa', 'bredasdorp', 'upernavik', 'hami', 'amapa', 'brae', 'kushiro', 'nalut', 'vila velha', 'mahebourg', 'halifax', 'taolanaro', 'port alfred', 'ribeira grande', 'ponta do sol', 'vilhena', 'albany', 'vaini', 'mataura', 'cape town', 'nanortalik', 'te anau', 'vaini', 'tuktoyaktuk', 'adrar', 'mataura', 'bilibino', 'shubarkuduk', 'nouadhibou', 'antsohihy', 'eenhana', 'viru', 'hobart', 'mataura', 'bredasdorp', 'atuona', 'nelson bay', 'bredasdorp', 'vardo', 'hermanus', 'illoqqortoormiut', 'atuona', 'cape town', 'vaini', 'san policarpo', 'rikitea', 'longyearbyen', 'sinkat', 'kampot', 'busselton', 'kapaa', 'tan an', 'punta arenas', 'lensk', 'columbus', 'ushuaia', 'new norfolk', 'erenhot', 'abha', 'new norfolk', 'lafiagi', 'torres', 'luwuk', 'saskylakh', 'dikson', 'busselton', 'faanui', 'marcona', 'punta arenas', 'puerto ayora', 'talnakh', 'hermanus', 'bluff', 'rikitea', 'meulaboh', 'avarua', 'kavieng', 'vostok', 'jamestown', 'saint anthony', 'coolum beach', 'kodiak', 'abnub', 'hithadhoo', 'mentok', 'stokmarknes', 'castro', 'chifeng', 'new norfolk', 'ushuaia', 'mataura', 'narsaq', 'necochea', 'ushuaia', 'hithadhoo', 'hermanus', 'bandundu', 'mataura', 'torbay', 'tonj', 'dunedin', 'ushuaia', 'acarau', 'tasiilaq', 'buraydah', 'taolanaro', 'mataura', 'saint george', 'acapulco', 'bluff', 'solnechnyy', 'sorvag', 'port alfred', 'pampa', 'avarua', 'mataura', 'padang', 'kodiak', 'tumannyy', 'busselton', 'bouna', 'lebu', 'busselton', 'saint george', 'sofiysk', 'albany', 'nikolskoye', 'yulara', 'mataura', 'ushuaia', 'mwandiga', 'lagoa', 'chapais', 'eydhafushi', 'seoul', 'airai', 'vardo', 'sitka', 'beringovskiy', 'dikson', 'vaini', 'namibe', 'saskylakh', 'saint george', 'iqaluit', 'indiana', 'pevek', 'muravlenko', 'sabha', 'avarua', 'keflavik', 'rikitea', 'punta arenas', 'kodiak', 'port alfred', 'illoqqortoormiut', 'sisimiut', 'saint george', 'xilitla', 'amga', 'bluff', 'byron bay', 'sinnamary', 'cam ranh', 'bontang', 'mahajanga', 'mahebourg', 'mastic beach', 'ilulissat', 'mar del plata', 'cape town', 'ust-kamchatsk', 'san mateo ixtatan', 'atuona', 'ushuaia', 'cape town', 'albany', 'atuona', 'roald', 'murray bridge', 'illoqqortoormiut', 'lucapa', 'new ulm', 'ushuaia', 'rikitea', 'constitucion', 'port elizabeth', 'tasiilaq', 'maldonado', 'torbay', 'busselton', 'punta arenas', 'santa rosa', 'rikitea', 'pisco', 'bardiyah', 'mount gambier', 'hilo', 'cape town', 'lebu', 'hobart', 'atuona', 'sao filipe', 'nizwa', 'malpe', 'ushuaia', 'albany', 'qaanaaq', 'novogornyy', 'manalurpet', 'ushuaia', 'attawapiskat', 'kapaa', 'cape town', 'castro', 'los llanos de aridane', 'rikitea', 'hilo', 'jamestown', 'mahebourg', 'jamestown', 'illoqqortoormiut', 'bastia', 'ribeira grande', 'derzhavinsk', 'mandalgovi', 'mataura', 'luderitz', 'mar del plata', 'tuktoyaktuk', 'mar del plata', 'mataura', 'falealupo', 'puerto ayora', 'bada', 'genhe', 'butaritari', 'dikson', 'hermanus', 'korla', 'dikson', 'illoqqortoormiut', 'taolanaro', 'namibe', 'kampong thum', 'castro', 'port augusta', 'grimshaw', 'hithadhoo', 'pisco', 'castro', 'pevek', 'hihifo', 'mataura', 'ipixuna', 'rovenki', 'ulladulla', 'khorramshahr', 'adre', 'ushuaia', 'avarua', 'albany', 'punta arenas', 'svetlogorsk', 'busselton', 'ribeira grande', 'tasiilaq', 'suicheng', 'krumovgrad', 'tymovskoye', 'tasiilaq', 'macaboboni', 'bluff', 'kapaa', 'puerto ayora', 'cape town', 'saleaula', 'avarua', 'yermakovskoye', 'belushya guba', 'albany', 'mar del plata', 'busselton', 'busselton', 'busselton', 'makakilo city', 'saint-philippe', 'elko', 'kruisfontein', 'busselton', 'telimele', 'umba', 'cape town', 'saint george', 'kapaa', 'rikitea', 'krasnoarmeysk', 'east london', 'merauke', 'bredasdorp', 'seymchan', 'ramasukha', 'bubaque', 'tuktoyaktuk', 'toliary', 'port hedland', 'rikitea', 'hermanus', 'nguiu', 'ribeira grande', 'yellowknife', 'parabel', 'dingle', 'hermanus', 'souillac', 'punta arenas', 'punta arenas', 'kjollefjord', 'kysyl-syr', 'mataura', 'saint-philippe', 'samarai', 'itupiranga', 'hilo', 'tasiilaq', 'labuhan', 'honiara', 'port elizabeth', 'belushya guba', 'bowen', 'juneau', 'waw', 'hithadhoo', 'cidreira', 'thompson', 'praia da vitoria', 'kaitong', 'new norfolk', 'naze', 'aksay', 'kampene', 'tuktoyaktuk', 'hofn', 'mataura', 'cabedelo', 'bereda', 'jizan', 'asayita', 'khatanga', 'noumea', 'boende', 'vaini', 'bougouni', 'rio gallegos', 'inongo', 'khatanga', 'cape town', 'nishihara', 'albany', 'sao filipe', 'ushuaia', 'port-cartier', 'kaitangata', 'gambiran', 'busselton', 'ukwa', 'grindavik', 'inhambane', 'punta arenas', 'hasaki', 'rikitea', 'atuona', 'ushuaia', 'busselton', 'new norfolk', 'new norfolk', 'miri', 'provideniya', 'ixtapa', 'samusu', 'apatity', 'new norfolk', 'kamenskoye', 'sulurpeta', 'upernavik', 'castro', 'chokurdakh', 'salinas', 'road town', 'yulara', 'souillac', 'hermanus', 'banes', 'avarua', 'petropavlovsk-kamchatskiy']





    600




```python
# get api call and get response info

settings = {"units": "imperial", "appid": api_key}

info = []

for i in city_list:

    try:
        current_weather = owm.get_current(i, **settings)
        summary = ["name","main.temp", "main.humidity", "wind.speed", "clouds.all", "coord.lat"]
        data = current_weather(*summary)
        info.append(data)
        
        
    except:
        print("invalid city")

        
#print(info)
```

    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    invalid city
    [('Dingle', 74.66, 99, 15.99, 92, 11), ('Thompson', 24.8, 58, 11.41, 75, 55.74), ('Ushuaia', 46.4, 70, 9.17, 40, -54.81), ('Ocampo', 79.74, 90, 14.83, 76, 13.56), ('Kodiak', 35.6, 80, 14.99, 90, 39.95), ('Konskie', 44.91, 94, 13.65, 76, 51.19), ('Georgetown', 73.4, 94, 4.7, 0, 6.8), ('Dossor', 19.31, 88, 9.62, 76, 47.52), ('Fukue', 53.6, 37, 10.29, 0, 35.03), ('Rikitea', 80.28, 100, 18.23, 88, -23.12), ('Qaanaaq', -11.03, 100, 2.35, 56, 77.48), ('Faanui', 80.91, 100, 12.19, 76, -16.48), ('Mataura', 70.47, 57, 18.41, 20, -46.19), ('Jamestown', 67.32, 88, 9.35, 32, -33.21), ('Nardaran', 42.8, 100, 13.87, 90, 40.56), ('Tasiilaq', 21.2, 62, 6.93, 20, 65.61), ('Castro', 56.34, 98, 12.37, 92, -42.48), ('Bethel', 14, 72, 9.17, 90, 60.79), ('Ponta do Sol', 65.25, 88, 2.24, 0, -20.63), ('Bluff', 86.67, 38, 12.64, 0, -23.58), ('Carnarvon', 53.78, 76, 11.92, 0, -30.97), ('Charters Towers', 77.45, 74, 12.59, 36, -20.07), ('Avarua', 84.2, 70, 9.17, 20, -21.21), ('Gobabis', 60.8, 59, 2.24, 0, -22.45), ('Jamestown', 67.32, 88, 9.35, 32, -33.21), ('Lata', 46.58, 64, 2.13, 0, 30.78), ('Dudinka', -26.06, 40, 4.25, 12, 69.41), ('Thompson', 24.8, 58, 11.41, 75, 55.74), ('Almeirim', 52.84, 87, 9.17, 40, 39.21), ('Dalvik', 33.8, 100, 5.82, 92, 57.79), ('Tuatapere', 64.76, 82, 18.34, 12, -46.13), ('Hovd', 30.2, 68, 11.41, 0, 63.83), ('Rikitea', 80.28, 100, 18.23, 88, -23.12), ('Port-Gentil', 80.55, 98, 7.27, 64, -0.72), ('Kapaa', 70.61, 60, 18.34, 20, 22.08), ('Soyo', 75.38, 98, 2.8, 68, -6.13), ('Narsaq', 30.2, 39, 14.99, 20, 60.91), ('Bredasdorp', 62.6, 82, 7.16, 56, -34.53), ('Saint-Philippe', 31.1, 87, 9.17, 90, 45.36), ('Vaini', 74.03, 52, 4.09, 0, 15.34), ('Ushuaia', 46.4, 70, 9.17, 40, -54.81), ('Ribeira Grande', 62.19, 99, 26.51, 92, 38.52), ('Hobart', 66.2, 48, 8.05, 75, -42.88), ('Albany', 30.16, 78, 3.87, 90, 42.65), ('Hobart', 66.2, 48, 8.05, 75, -42.88), ('Eureka', 50.56, 100, 6.93, 1, 40.8), ('Carnarvon', 53.78, 76, 11.92, 0, -30.97), ('Laguna', 79.92, 34, 6.11, 32, 27.52), ('Rikitea', 80.28, 100, 18.23, 88, -23.12), ('Kloulklubed', 88.65, 52, 8.05, 75, 7.04), ('Bluff', 86.67, 38, 12.64, 0, -23.58), ('Remedios', 71.6, 83, 2.24, 20, 22.5), ('Ushuaia', 46.4, 70, 9.17, 40, -54.81), ('Panzhihua', 66.06, 44, 3.53, 0, 26.59), ('Cape Town', 60.8, 87, 2.24, 0, -33.93), ('Hobart', 66.2, 48, 8.05, 75, -42.88), ('Ribeira Grande', 62.19, 99, 26.51, 92, 38.52), ('Makakilo City', 73.4, 53, 9.17, 20, 21.35), ('Nikolskoye', 21.2, 100, 4.47, 75, 59.7), ('Longyearbyen', 6.8, 71, 13.87, 0, 78.22), ('Zhezkazgan', 17.6, 92, 11.18, 90, 47.8), ('Chokurdakh', -26.78, 42, 3.13, 8, 70.62), ('East London', 66.2, 82, 5.82, 0, -33.02), ('Katsuura', 53.6, 46, 5.82, 0, 33.93), ('Kuching', 80.6, 88, 8.05, 75, 1.56), ('Hobart', 66.2, 48, 8.05, 75, -42.88), ('Pennsville', 32.54, 68, 5.82, 1, 39.65), ('Sitka', 40.1, 46, 7.38, 0, 37.17), ('Labytnangi', -6.8, 75, 9.4, 76, 66.66), ('Ponta do Sol', 65.25, 88, 2.24, 0, -20.63), ('Rikitea', 80.28, 100, 18.23, 88, -23.12), ('Saint-Philippe', 31.1, 87, 9.17, 90, 45.36), ('Buala', 84.2, 87, 20.13, 76, -8.15), ('Lazaro Cardenas', 55.4, 43, 14.99, 5, 28.39), ('Nikolskoye', 21.2, 100, 4.47, 75, 59.7), ('Rikitea', 80.28, 100, 18.23, 88, -23.12), ('Danjiangkou', 63.23, 77, 2.86, 0, 32.54), ('Airai', 80.82, 77, 1.57, 12, -8.93), ('Zarate', 71.6, 78, 4.7, 0, -13.68), ('Qeshm', 64.4, 82, 2.24, 0, 26.96), ('Hamilton', 66.2, 82, 12.75, 75, 32.3), ('Bad Neuenahr-Ahrweiler', 45.79, 87, 4.7, 0, 50.54), ('Sorland', 37.53, 100, 18.41, 88, 67.67), ('Dukat', 37.71, 89, 2.01, 92, 42.44), ('Roald', 32.77, 80, 17.22, 32, 62.58), ('Mataura', 70.47, 57, 18.41, 20, -46.19), ('Mataura', 70.47, 57, 18.41, 20, -46.19), ('Mataura', 70.47, 57, 18.41, 20, -46.19), ('Rikitea', 80.28, 100, 18.23, 88, -23.12), ('Mataura', 70.47, 57, 18.41, 20, -46.19), ('Pitimbu', 77, 88, 3.36, 40, -7.47), ('Bambous Virieux', 80.6, 83, 16.11, 75, -20.34), ('Inyonga', 63.45, 98, 1.9, 56, -6.72), ('Georgetown', 73.4, 94, 4.7, 0, 6.8), ('Sao Jose da Coroa Grande', 77.18, 92, 10.13, 0, -8.9), ('Kapaa', 70.61, 60, 18.34, 20, 22.08), ('Zeya', 14, 69, 2.75, 80, 53.74), ('Port Alfred', 64.58, 100, 5.66, 12, -33.59), ('Lorengau', 81.5, 100, 11.14, 36, -2.02), ('Port Elizabeth', 32.95, 68, 2.8, 1, 39.31), ('Rikitea', 80.28, 100, 18.23, 88, -23.12), ('Hobart', 66.2, 48, 8.05, 75, -42.88), ('Norman Wells', 26.6, 45, 10.29, 75, 65.28), ('Khumalag', 31.23, 96, 3.13, 92, 43.24), ('Longyearbyen', 6.8, 71, 13.87, 0, 78.22), ('Ushuaia', 46.4, 70, 9.17, 40, -54.81), ('Hamilton', 66.2, 82, 12.75, 75, 32.3), ('Albany', 30.16, 78, 3.87, 90, 42.65), ('Carnarvon', 53.78, 76, 11.92, 0, -30.97), ('Albany', 30.16, 78, 3.87, 90, 42.65), ('Ahipara', 63.09, 100, 27.51, 92, -35.17), ('Rikitea', 80.28, 100, 18.23, 88, -23.12), ('Tuktoyaktuk', -3.27, 76, 13.87, 20, 69.44), ('Georgetown', 73.4, 94, 4.7, 0, 6.8), ('Matara', 43.25, 97, 0.74, 56, -13.74), ('Port Blair', 83.97, 100, 12.15, 32, 11.67), ('Rikitea', 80.28, 100, 18.23, 88, -23.12), ('Lantawan', 80.6, 83, 20.8, 90, 10.57), ('Castro', 56.34, 98, 12.37, 92, -42.48), ('Busselton', 75.51, 82, 15.21, 0, -33.64), ('Punta Arenas', 46.4, 75, 8.05, 75, -53.16), ('Matamoros', 69.4, 64, 17.22, 90, 25.87), ('Meulaboh', 81.36, 100, 3.24, 0, 4.14), ('Busselton', 75.51, 82, 15.21, 0, -33.64), ('Bredasdorp', 62.6, 82, 7.16, 56, -34.53), ('Longyearbyen', 6.8, 71, 13.87, 0, 78.22), ('Ushuaia', 46.4, 70, 9.17, 40, -54.81), ('Yellowknife', 14, 78, 2.24, 20, 62.45), ('Dodge City', 32.34, 63, 6.93, 1, 37.75), ('Juneau', 37.51, 93, 9.46, 90, 58.3), ('Baruun-Urt', 48.33, 55, 5.82, 48, 46.68), ('Avarua', 84.2, 70, 9.17, 20, -21.21), ('Flinders', 73.4, 69, 11.41, 40, -34.58), ('Lebu', 45.9, 53, 2.53, 20, 8.96), ('Rikitea', 80.28, 100, 18.23, 88, -23.12), ('Morant Bay', 80.6, 78, 18.34, 20, 17.88), ('Nikolskoye', 21.2, 100, 4.47, 75, 59.7), ('Punta Arenas', 46.4, 75, 8.05, 75, -53.16), ('Hasaki', 52.65, 32, 11.41, 20, 35.73), ('Punta Arenas', 46.4, 75, 8.05, 75, -53.16), ('Ushuaia', 46.4, 70, 9.17, 40, -54.81), ('Maua', 59, 82, 2.08, 20, 0.23), ('Avarua', 84.2, 70, 9.17, 20, -21.21), ('Tuktoyaktuk', -3.27, 76, 13.87, 20, 69.44), ('Kamaishi', 41, 48, 12.75, 40, 39.28), ('Atuona', 81.68, 100, 17, 92, -9.8), ('Katherine', 89.6, 52, 14.99, 75, -14.47), ('East London', 66.2, 82, 5.82, 0, -33.02), ('Teya', 78.8, 78, 5.82, 5, 21.05), ('Albany', 30.16, 78, 3.87, 90, 42.65), ('Rawson', 60.75, 47, 12.19, 20, -43.3), ('Puqi', 67.59, 84, 3.91, 0, 29.72), ('Seymchan', -12.38, 75, 5.93, 32, 62.93), ('Kruisfontein', 58.23, 83, 3.31, 0, -34), ('Puerto Ayora', 79.43, 97, 7.45, 0, -0.74), ('Torbay', 28.4, 100, 9.17, 90, 47.66), ('Mount Gambier', 66.65, 65, 7.05, 24, -37.83), ('Taoudenni', 66.83, 17, 10.96, 0, 22.68), ('Batagay', -16.7, 72, 4.36, 0, 67.65), ('Kadhan', 68.81, 70, 3.02, 0, 24.48), ('Fort Nelson', 33.8, 59, 3.36, 75, 58.81), ('Gravdal', 32, 100, 4.7, 90, 59.79), ('Hilo', 65.3, 53, 9.17, 90, 19.71), ('Atuona', 81.68, 100, 17, 92, -9.8), ('Constitucion', 73.4, 15, 8.05, 75, 23.99), ('Port Alfred', 64.58, 100, 5.66, 12, -33.59), ('Thompson', 24.8, 58, 11.41, 75, 55.74), ('Rikitea', 80.28, 100, 18.23, 88, -23.12), ('Sangmelima', 68.4, 96, 2.64, 36, 2.93), ('Mount Gambier', 66.65, 65, 7.05, 24, -37.83), ('Santa Isabel do Rio Negro', 85.05, 56, 7.78, 0, -0.41), ('Vaini', 74.03, 52, 4.09, 0, 15.34), ('Kapaa', 70.61, 60, 18.34, 20, 22.08), ('Evensk', 3.42, 100, 2.35, 48, 61.92), ('Pevek', -9.54, 100, 7.11, 48, 69.7), ('Nikolskoye', 21.2, 100, 4.47, 75, 59.7), ('Rio Gallegos', 51.8, 57, 3.36, 40, -51.62), ('Mataura', 70.47, 57, 18.41, 20, -46.19), ('Elk Plain', 52.45, 50, 5.82, 1, 47.04), ('Saint-Philippe', 31.1, 87, 9.17, 90, 45.36), ('Mokhsogollokh', -0.72, 65, 3.8, 36, 61.4), ('Bethel', 14, 72, 9.17, 90, 60.79), ('Cayenne', 78.8, 78, 11.41, 75, 4.94), ('Rikitea', 80.28, 100, 18.23, 88, -23.12), ('Kapaa', 70.61, 60, 18.34, 20, 22.08), ('Bredasdorp', 62.6, 82, 7.16, 56, -34.53), ('Upernavik', 3.6, 92, 1.23, 64, 72.79), ('Hami', 54.41, 48, 4.59, 0, 42.84), ('Amapa', 80.6, 88, 6.93, 20, 15.09), ('Brae', 39.2, 80, 16.11, 92, 60.4), ('Kushiro', 35.6, 69, 6.93, 40, 43.11), ('Nalut', 57.87, 48, 6.89, 0, 31.86), ('Vila Velha', 82.4, 78, 6.93, 40, -3.71), ('Mahebourg', 80.6, 83, 16.11, 75, -20.41), ('Halifax', 30.2, 100, 12.75, 90, 44.65), ('Port Alfred', 64.58, 100, 5.66, 12, -33.59), ('Ribeira Grande', 62.19, 99, 26.51, 92, 38.52), ('Ponta do Sol', 65.25, 88, 2.24, 0, -20.63), ('Vilhena', 73.4, 100, 4.7, 0, -12.74), ('Albany', 30.16, 78, 3.87, 90, 42.65), ('Vaini', 74.03, 52, 4.09, 0, 15.34), ('Mataura', 70.47, 57, 18.41, 20, -46.19), ('Cape Town', 60.8, 87, 2.24, 0, -33.93), ('Nanortalik', 29.7, 94, 14.83, 0, 60.14), ('Te Anau', 60.57, 70, 12.19, 36, -45.41), ('Vaini', 74.03, 52, 4.09, 0, 15.34), ('Tuktoyaktuk', -3.27, 76, 13.87, 20, 69.44), ('Adrar', 57.2, 11, 6.93, 0, 27.87), ('Mataura', 70.47, 57, 18.41, 20, -46.19), ('Bilibino', -16.43, 46, 3.24, 36, 68.06), ('Shubarkuduk', 9.5, 83, 13.94, 76, 49.15), ('Nouadhibou', 64.4, 63, 21.92, 12, 20.93), ('Antsohihy', 70.43, 97, 4.65, 8, -14.88), ('Eenhana', 72.9, 38, 5.93, 92, -17.48), ('Viru', 28.4, 86, 10.29, 76, 57.74), ('Hobart', 66.2, 48, 8.05, 75, -42.88), ('Mataura', 70.47, 57, 18.41, 20, -46.19), ('Bredasdorp', 62.6, 82, 7.16, 56, -34.53), ('Atuona', 81.68, 100, 17, 92, -9.8), ('Nelson Bay', 78.8, 50, 13.87, 40, -32.72), ('Bredasdorp', 62.6, 82, 7.16, 56, -34.53), ('Vardo', 33.82, 74, 3.76, 1, 39.62), ('Hermanus', 51.21, 94, 2.91, 0, -34.42), ('Atuona', 81.68, 100, 17, 92, -9.8), ('Cape Town', 60.8, 87, 2.24, 0, -33.93), ('Vaini', 74.03, 52, 4.09, 0, 15.34), ('San Policarpo', 77.45, 100, 15.43, 92, 12.18), ('Rikitea', 80.28, 100, 18.23, 88, -23.12), ('Longyearbyen', 6.8, 71, 13.87, 0, 78.22), ('Kampot', 86.13, 57, 5.77, 0, 10.62), ('Busselton', 75.51, 82, 15.21, 0, -33.64), ('Kapaa', 70.61, 60, 18.34, 20, 22.08), ('Tan An', 87.8, 55, 4.7, 20, 10.54), ('Punta Arenas', 46.4, 75, 8.05, 75, -53.16), ('Lensk', 5.63, 64, 4.59, 44, 60.71), ('Columbus', 54.7, 93, 4.32, 90, 32.46), ('Ushuaia', 46.4, 70, 9.17, 40, -54.81), ('New Norfolk', 66.2, 48, 8.05, 75, -42.78), ('Erenhot', 53.55, 39, 14.16, 8, 43.65), ('Abha', 54.55, 50, 5.82, 0, 18.22), ('New Norfolk', 66.2, 48, 8.05, 75, -42.78), ('Lafiagi', 75.87, 74, 7.78, 0, 8.85), ('Torres', 70.92, 100, 8.16, 92, -29.34), ('Luwuk', 87.8, 70, 1.86, 8, -0.95), ('Saskylakh', -25.7, 39, 5.44, 32, 71.97), ('Dikson', -9.05, 100, 20.36, 56, 73.51), ('Busselton', 75.51, 82, 15.21, 0, -33.64), ('Faanui', 80.91, 100, 12.19, 76, -16.48), ('Punta Arenas', 46.4, 75, 8.05, 75, -53.16), ('Puerto Ayora', 79.43, 97, 7.45, 0, -0.74), ('Talnakh', -27.41, 85, 2.57, 8, 69.49), ('Hermanus', 51.21, 94, 2.91, 0, -34.42), ('Bluff', 86.67, 38, 12.64, 0, -23.58), ('Rikitea', 80.28, 100, 18.23, 88, -23.12), ('Meulaboh', 81.36, 100, 3.24, 0, 4.14), ('Avarua', 84.2, 70, 9.17, 20, -21.21), ('Kavieng', 86, 98, 11.48, 0, -2.57), ('Vostok', 21.2, 55, 2.86, 20, 46.45), ('Jamestown', 67.32, 88, 9.35, 32, -33.21), ('Saint Anthony', 34.43, 100, 6.93, 90, 43.97), ('Coolum Beach', 70.43, 100, 8.39, 92, -26.53), ('Kodiak', 35.6, 80, 14.99, 90, 39.95), ('Abnub', 53.6, 71, 5.82, 0, 27.27), ('Hithadhoo', 81.54, 100, 7.67, 56, -0.6), ('Stokmarknes', 30.2, 86, 3.36, 75, 68.56), ('Castro', 56.34, 98, 12.37, 92, -42.48), ('Chifeng', 54.45, 53, 9.57, 20, 42.27), ('New Norfolk', 66.2, 48, 8.05, 75, -42.78), ('Ushuaia', 46.4, 70, 9.17, 40, -54.81), ('Mataura', 70.47, 57, 18.41, 20, -46.19), ('Narsaq', 30.2, 39, 14.99, 20, 60.91), ('Necochea', 48.42, 98, 3.76, 0, -38.55), ('Ushuaia', 46.4, 70, 9.17, 40, -54.81), ('Hithadhoo', 81.54, 100, 7.67, 56, -0.6), ('Hermanus', 51.21, 94, 2.91, 0, -34.42), ('Bandundu', 74.66, 94, 5.32, 48, -3.32), ('Mataura', 70.47, 57, 18.41, 20, -46.19), ('Torbay', 28.4, 100, 9.17, 90, 47.66), ('Dunedin', 68.4, 67, 5.32, 20, -45.87), ('Ushuaia', 46.4, 70, 9.17, 40, -54.81), ('Tasiilaq', 21.2, 62, 6.93, 20, 65.61), ('Buraydah', 60.8, 55, 5.82, 20, 26.33), ('Mataura', 70.47, 57, 18.41, 20, -46.19), ('Saint George', 42.8, 93, 2.08, 0, 39.45), ('Acapulco', 77, 83, 4.7, 20, 16.86), ('Bluff', 86.67, 38, 12.64, 0, -23.58), ('Solnechnyy', 21.56, 73, 6.67, 0, 50.72), ('Port Alfred', 64.58, 100, 5.66, 12, -33.59), ('Pampa', 39.09, 44, 5.82, 1, 35.54), ('Avarua', 84.2, 70, 9.17, 20, -21.21), ('Mataura', 70.47, 57, 18.41, 20, -46.19), ('Padang', 83.34, 100, 5.93, 0, -0.92), ('Kodiak', 35.6, 80, 14.99, 90, 39.95), ('Busselton', 75.51, 82, 15.21, 0, -33.64), ('Bouna', 75.38, 82, 7.11, 24, 9.27), ('Lebu', 45.9, 53, 2.53, 20, 8.96), ('Busselton', 75.51, 82, 15.21, 0, -33.64), ('Saint George', 42.8, 93, 2.08, 0, 39.45), ('Albany', 30.16, 78, 3.87, 90, 42.65), ('Nikolskoye', 21.2, 100, 4.47, 75, 59.7), ('Yulara', 93.2, 12, 17.22, 0, -25.24), ('Mataura', 70.47, 57, 18.41, 20, -46.19), ('Ushuaia', 46.4, 70, 9.17, 40, -54.81), ('Mwandiga', 67.14, 100, 3.91, 92, -4.84), ('Lagoa', 55.4, 76, 8.05, 20, 37.14), ('Chapais', 21.2, 85, 3.36, 90, 49.78), ('Eydhafushi', 84.2, 98, 14.61, 36, 5.1), ('Seoul', 53.98, 43, 5.82, 8, 37.57), ('Airai', 80.82, 77, 1.57, 12, -8.93), ('Vardo', 33.82, 74, 3.76, 1, 39.62), ('Sitka', 40.1, 46, 7.38, 0, 37.17), ('Beringovskiy', 16.74, 95, 26.46, 80, 63.05), ('Dikson', -9.05, 100, 20.36, 56, 73.51), ('Vaini', 74.03, 52, 4.09, 0, 15.34), ('Namibe', 72.09, 100, 6.38, 48, -15.19), ('Saskylakh', -25.7, 39, 5.44, 32, 71.97), ('Saint George', 42.8, 93, 2.08, 0, 39.45), ('Iqaluit', 8.6, 84, 3.58, 90, 63.75), ('Indiana', 26.6, 73, 3.53, 1, 40.62), ('Pevek', -9.54, 100, 7.11, 48, 69.7), ('Muravlenko', -22.68, 67, 9.28, 8, 63.79), ('Sabha', 64.76, 26, 12.41, 0, 27.03), ('Avarua', 84.2, 70, 9.17, 20, -21.21), ('Keflavik', 28.4, 79, 4.7, 0, 64), ('Rikitea', 80.28, 100, 18.23, 88, -23.12), ('Punta Arenas', 46.4, 75, 8.05, 75, -53.16), ('Kodiak', 35.6, 80, 14.99, 90, 39.95), ('Port Alfred', 64.58, 100, 5.66, 12, -33.59), ('Sisimiut', 7.38, 82, 1.34, 92, 66.94), ('Saint George', 42.8, 93, 2.08, 0, 39.45), ('Xilitla', 78.98, 58, 7.05, 24, 21.39), ('Amga', -1.26, 55, 3.76, 24, 60.89), ('Bluff', 86.67, 38, 12.64, 0, -23.58), ('Byron Bay', 78.8, 57, 10.29, 75, -28.65), ('Sinnamary', 79.61, 94, 13.38, 92, 5.38), ('Cam Ranh', 76.95, 85, 13.42, 44, 11.92), ('Bontang', 84.11, 90, 11.18, 12, 0.12), ('Mahajanga', 77, 94, 2.24, 20, -15.72), ('Mahebourg', 80.6, 83, 16.11, 75, -20.41), ('Mastic Beach', 31.53, 100, 3.36, 1, 40.77), ('Ilulissat', 10.4, 60, 1.12, 92, 69.22), ('Mar del Plata', 60.84, 56, 16.96, 0, -46.43), ('Cape Town', 60.8, 87, 2.24, 0, -33.93), ('San Mateo Ixtatan', 56.03, 79, 0.51, 0, 15.83), ('Atuona', 81.68, 100, 17, 92, -9.8), ('Ushuaia', 46.4, 70, 9.17, 40, -54.81), ('Cape Town', 60.8, 87, 2.24, 0, -33.93), ('Albany', 30.16, 78, 3.87, 90, 42.65), ('Atuona', 81.68, 100, 17, 92, -9.8), ('Roald', 32.77, 80, 17.22, 32, 62.58), ('Murray Bridge', 67.77, 82, 14.16, 0, -35.12), ('Lucapa', 65.16, 98, 3.91, 92, -8.42), ('New Ulm', 29.07, 86, 19.46, 90, 44.31), ('Ushuaia', 46.4, 70, 9.17, 40, -54.81), ('Rikitea', 80.28, 100, 18.23, 88, -23.12), ('Constitucion', 73.4, 15, 8.05, 75, 23.99), ('Port Elizabeth', 32.95, 68, 2.8, 1, 39.31), ('Tasiilaq', 21.2, 62, 6.93, 20, 65.61), ('Maldonado', 66.2, 55, 18.34, 75, -34.91), ('Torbay', 28.4, 100, 9.17, 90, 47.66), ('Busselton', 75.51, 82, 15.21, 0, -33.64), ('Punta Arenas', 46.4, 75, 8.05, 75, -53.16), ('Santa Rosa', 56.7, 42, 7.78, 0, -36.62), ('Rikitea', 80.28, 100, 18.23, 88, -23.12), ('Pisco', 71.6, 78, 4.7, 0, -13.71), ('Mount Gambier', 66.65, 65, 7.05, 24, -37.83), ('Hilo', 65.3, 53, 9.17, 90, 19.71), ('Cape Town', 60.8, 87, 2.24, 0, -33.93), ('Lebu', 45.9, 53, 2.53, 20, 8.96), ('Hobart', 66.2, 48, 8.05, 75, -42.88), ('Atuona', 81.68, 100, 17, 92, -9.8), ('Sao Filipe', 71.19, 94, 19.75, 68, 14.9), ('Nizwa', 50.67, 76, 2.53, 0, 22.93), ('Malpe', 80.6, 78, 4.7, 0, 13.35), ('Ushuaia', 46.4, 70, 9.17, 40, -54.81), ('Albany', 30.16, 78, 3.87, 90, 42.65), ('Qaanaaq', -11.03, 100, 2.35, 56, 77.48), ('Novogornyy', -2.21, 84, 2.75, 20, 55.63), ('Ushuaia', 46.4, 70, 9.17, 40, -54.81), ('Kapaa', 70.61, 60, 18.34, 20, 22.08), ('Cape Town', 60.8, 87, 2.24, 0, -33.93), ('Castro', 56.34, 98, 12.37, 92, -42.48), ('Los Llanos de Aridane', 60.8, 77, 6.93, 0, 28.66), ('Rikitea', 80.28, 100, 18.23, 88, -23.12), ('Hilo', 65.3, 53, 9.17, 90, 19.71), ('Jamestown', 67.32, 88, 9.35, 32, -33.21), ('Mahebourg', 80.6, 83, 16.11, 75, -20.41), ('Jamestown', 67.32, 88, 9.35, 32, -33.21), ('Bastia', 51.8, 87, 5.82, 75, 44.6), ('Ribeira Grande', 62.19, 99, 26.51, 92, 38.52), ('Derzhavinsk', 5.58, 82, 13.65, 56, 51.1), ('Mandalgovi', 43.2, 82, 11.3, 0, 45.76), ('Mataura', 70.47, 57, 18.41, 20, -46.19), ('Luderitz', 62.6, 88, 1.12, 24, -26.65), ('Mar del Plata', 60.84, 56, 16.96, 0, -46.43), ('Tuktoyaktuk', -3.27, 76, 13.87, 20, 69.44), ('Mar del Plata', 60.84, 56, 16.96, 0, -46.43), ('Mataura', 70.47, 57, 18.41, 20, -46.19), ('Puerto Ayora', 79.43, 97, 7.45, 0, -0.74), ('Bada', 66.83, 59, 2.64, 0, 12.41), ('Genhe', 31.41, 77, 5.59, 32, 50.78), ('Butaritari', 82.85, 100, 14.65, 88, 3.07), ('Dikson', -9.05, 100, 20.36, 56, 73.51), ('Hermanus', 51.21, 94, 2.91, 0, -34.42), ('Dikson', -9.05, 100, 20.36, 56, 73.51), ('Namibe', 72.09, 100, 6.38, 48, -15.19), ('Kampong Thum', 87.84, 46, 9.84, 0, 12.71), ('Castro', 56.34, 98, 12.37, 92, -42.48), ('Port Augusta', 73.4, 46, 19.46, 44, -32.49), ('Grimshaw', 23, 73, 4.7, 20, 56.19), ('Hithadhoo', 81.54, 100, 7.67, 56, -0.6), ('Pisco', 71.6, 78, 4.7, 0, -13.71), ('Castro', 56.34, 98, 12.37, 92, -42.48), ('Pevek', -9.54, 100, 7.11, 48, 69.7), ('Mataura', 70.47, 57, 18.41, 20, -46.19), ('Ipixuna', 77, 94, 3.36, 0, -1.76), ('Rovenki', 8.15, 89, 6.89, 8, 49.91), ('Ulladulla', 73.4, 69, 11.41, 40, -35.36), ('Khorramshahr', 59.23, 67, 4.7, 0, 30.43), ('Adre', 68.49, 18, 14.09, 0, 13.47), ('Ushuaia', 46.4, 70, 9.17, 40, -54.81), ('Avarua', 84.2, 70, 9.17, 20, -21.21), ('Albany', 30.16, 78, 3.87, 90, 42.65), ('Punta Arenas', 46.4, 75, 8.05, 75, -53.16), ('Svetlogorsk', -7.61, 76, 4.47, 75, 53.14), ('Busselton', 75.51, 82, 15.21, 0, -33.64), ('Ribeira Grande', 62.19, 99, 26.51, 92, 38.52), ('Tasiilaq', 21.2, 62, 6.93, 20, 65.61), ('Suicheng', 63.72, 55, 7.61, 0, 33.9), ('Krumovgrad', 37.4, 95, 3.09, 44, 41.47), ('Tymovskoye', 20.48, 58, 6.26, 0, 50.85), ('Tasiilaq', 21.2, 62, 6.93, 20, 65.61), ('Bluff', 86.67, 38, 12.64, 0, -23.58), ('Kapaa', 70.61, 60, 18.34, 20, 22.08), ('Puerto Ayora', 79.43, 97, 7.45, 0, -0.74), ('Cape Town', 60.8, 87, 2.24, 0, -33.93), ('Avarua', 84.2, 70, 9.17, 20, -21.21), ('Yermakovskoye', 13.95, 83, 6.15, 88, 53.28), ('Albany', 30.16, 78, 3.87, 90, 42.65), ('Mar del Plata', 60.84, 56, 16.96, 0, -46.43), ('Busselton', 75.51, 82, 15.21, 0, -33.64), ('Busselton', 75.51, 82, 15.21, 0, -33.64), ('Busselton', 75.51, 82, 15.21, 0, -33.64), ('Makakilo City', 73.4, 53, 9.17, 20, 21.35), ('Saint-Philippe', 31.1, 87, 9.17, 90, 45.36), ('Elko', 44.6, 56, 4.7, 1, 40.83), ('Kruisfontein', 58.23, 83, 3.31, 0, -34), ('Busselton', 75.51, 82, 15.21, 0, -33.64), ('Telimele', 66.96, 86, 3.09, 8, 10.9), ('Umba', 25.47, 94, 8.46, 88, 66.69), ('Cape Town', 60.8, 87, 2.24, 0, -33.93), ('Saint George', 42.8, 93, 2.08, 0, 39.45), ('Kapaa', 70.61, 60, 18.34, 20, 22.08), ('Rikitea', 80.28, 100, 18.23, 88, -23.12), ('Krasnoarmeysk', 23, 85, 6.71, 90, 56.12), ('East London', 66.2, 82, 5.82, 0, -33.02), ('Merauke', 80.6, 100, 10.58, 92, -8.49), ('Bredasdorp', 62.6, 82, 7.16, 56, -34.53), ('Seymchan', -12.38, 75, 5.93, 32, 62.93), ('Bubaque', 73.4, 88, 3.36, 0, 11.28), ('Tuktoyaktuk', -3.27, 76, 13.87, 20, 69.44), ('Port Hedland', 95, 47, 18.34, 36, -20.31), ('Rikitea', 80.28, 100, 18.23, 88, -23.12), ('Hermanus', 51.21, 94, 2.91, 0, -34.42), ('Ribeira Grande', 62.19, 99, 26.51, 92, 38.52), ('Yellowknife', 14, 78, 2.24, 20, 62.45), ('Parabel', -8.37, 65, 5.55, 0, 58.71), ('Dingle', 74.66, 99, 15.99, 92, 11), ('Hermanus', 51.21, 94, 2.91, 0, -34.42), ('Souillac', 50.81, 81, 17.22, 75, 45.6), ('Punta Arenas', 46.4, 75, 8.05, 75, -53.16), ('Punta Arenas', 46.4, 75, 8.05, 75, -53.16), ('Kjollefjord', 26.6, 92, 1.12, 90, 70.95), ('Kysyl-Syr', -3.96, 64, 3.8, 48, 63.9), ('Mataura', 70.47, 57, 18.41, 20, -46.19), ('Saint-Philippe', 31.1, 87, 9.17, 90, 45.36), ('Samarai', 84.56, 100, 12.37, 0, -10.62), ('Itupiranga', 77, 100, 1.12, 0, -5.13), ('Hilo', 65.3, 53, 9.17, 90, 19.71), ('Tasiilaq', 21.2, 62, 6.93, 20, 65.61), ('Labuhan', 84.15, 77, 3.24, 24, -2.54), ('Honiara', 87.8, 66, 14.99, 75, -9.43), ('Port Elizabeth', 32.95, 68, 2.8, 1, 39.31), ('Bowen', 82.4, 54, 18.34, 24, -20.01), ('Juneau', 37.51, 93, 9.46, 90, 58.3), ('Hithadhoo', 81.54, 100, 7.67, 56, -0.6), ('Cidreira', 68.49, 100, 7.61, 88, -30.17), ('Thompson', 24.8, 58, 11.41, 75, 55.74), ('Praia da Vitoria', 60.8, 93, 27.13, 40, 38.73), ('Kaitong', 39.38, 88, 10.63, 56, 44.81), ('New Norfolk', 66.2, 48, 8.05, 75, -42.78), ('Naze', 73.17, 95, 5.32, 44, 5.43), ('Aksay', 15.98, 79, 8.28, 0, 47.27), ('Kampene', 68.04, 97, 2.42, 92, -3.59), ('Tuktoyaktuk', -3.27, 76, 13.87, 20, 69.44), ('Hofn', 34.74, 100, 28.74, 92, 64.25), ('Mataura', 70.47, 57, 18.41, 20, -46.19), ('Cabedelo', 77, 88, 3.36, 40, -6.97), ('Bereda', 50, 81, 11.41, 92, 43.27), ('Jizan', 80.6, 74, 4.7, 40, 16.89), ('Khatanga', -21.15, 62, 8.28, 56, 71.98), ('Noumea', 82.4, 69, 3.36, 75, -22.28), ('Boende', 74.52, 93, 2.75, 92, -0.28), ('Vaini', 74.03, 52, 4.09, 0, 15.34), ('Bougouni', 73.98, 60, 6.15, 0, 11.42), ('Rio Gallegos', 51.8, 57, 3.36, 40, -51.62), ('Inongo', 74.79, 96, 3.91, 36, -1.93), ('Khatanga', -21.15, 62, 8.28, 56, 71.98), ('Cape Town', 60.8, 87, 2.24, 0, -33.93), ('Nishihara', 54.95, 30, 11.36, 1, 35.74), ('Albany', 30.16, 78, 3.87, 90, 42.65), ('Sao Filipe', 71.19, 94, 19.75, 68, 14.9), ('Ushuaia', 46.4, 70, 9.17, 40, -54.81), ('Port-Cartier', 30.2, 86, 2.24, 90, 50.03), ('Kaitangata', 70.92, 63, 4.76, 0, -46.28), ('Gambiran', 82.26, 79, 0.56, 20, -7.93), ('Busselton', 75.51, 82, 15.21, 0, -33.64), ('Ukwa', 73.98, 96, 6.11, 56, 5.47), ('Grindavik', 28.4, 79, 4.7, 0, 63.84), ('Inhambane', 72.23, 100, 4.88, 0, -23.87), ('Punta Arenas', 46.4, 75, 8.05, 75, -53.16), ('Hasaki', 52.65, 32, 11.41, 20, 35.73), ('Rikitea', 80.28, 100, 18.23, 88, -23.12), ('Atuona', 81.68, 100, 17, 92, -9.8), ('Ushuaia', 46.4, 70, 9.17, 40, -54.81), ('Busselton', 75.51, 82, 15.21, 0, -33.64), ('New Norfolk', 66.2, 48, 8.05, 75, -42.78), ('New Norfolk', 66.2, 48, 8.05, 75, -42.78), ('Miri', 60.21, 51, 3.91, 0, 10.31), ('Provideniya', 3.2, 65, 17.9, 75, 64.42), ('Ixtapa', 69.8, 68, 2.24, 5, 20.71), ('Apatity', 13.86, 82, 2.3, 76, 67.57), ('New Norfolk', 66.2, 48, 8.05, 75, -42.78), ('Upernavik', 3.6, 92, 1.23, 64, 72.79), ('Castro', 56.34, 98, 12.37, 92, -42.48), ('Chokurdakh', -26.78, 42, 3.13, 8, 70.62), ('Salinas', 55.38, 87, 5.82, 20, 36.67), ('Road Town', 73.4, 94, 9.17, 20, 18.42), ('Yulara', 93.2, 12, 17.22, 0, -25.24), ('Souillac', 50.81, 81, 17.22, 75, 45.6), ('Hermanus', 51.21, 94, 2.91, 0, -34.42), ('Banes', 77, 73, 5.82, 20, 20.96), ('Avarua', 84.2, 70, 9.17, 20, -21.21), ('Petropavlovsk-Kamchatskiy', 23, 41, 17.9, 44, 53.05)]



```python
df = pd.DataFrame(info)

df.columns = ["city","temperature", "humidity", "wind_speed", "Cloudiness", "latitude"]

#print(df)

df.to_csv("data.csv",encoding="utf-8", index=False)
```

                              city  temperature  humidity  wind_speed  Cloudiness  \
    0                       Dingle        74.66        99       15.99          92   
    1                     Thompson        24.80        58       11.41          75   
    2                      Ushuaia        46.40        70        9.17          40   
    3                       Ocampo        79.74        90       14.83          76   
    4                       Kodiak        35.60        80       14.99          90   
    5                      Konskie        44.91        94       13.65          76   
    6                   Georgetown        73.40        94        4.70           0   
    7                       Dossor        19.31        88        9.62          76   
    8                        Fukue        53.60        37       10.29           0   
    9                      Rikitea        80.28       100       18.23          88   
    10                     Qaanaaq       -11.03       100        2.35          56   
    11                      Faanui        80.91       100       12.19          76   
    12                     Mataura        70.47        57       18.41          20   
    13                   Jamestown        67.32        88        9.35          32   
    14                    Nardaran        42.80       100       13.87          90   
    15                    Tasiilaq        21.20        62        6.93          20   
    16                      Castro        56.34        98       12.37          92   
    17                      Bethel        14.00        72        9.17          90   
    18                Ponta do Sol        65.25        88        2.24           0   
    19                       Bluff        86.67        38       12.64           0   
    20                   Carnarvon        53.78        76       11.92           0   
    21             Charters Towers        77.45        74       12.59          36   
    22                      Avarua        84.20        70        9.17          20   
    23                     Gobabis        60.80        59        2.24           0   
    24                   Jamestown        67.32        88        9.35          32   
    25                        Lata        46.58        64        2.13           0   
    26                     Dudinka       -26.06        40        4.25          12   
    27                    Thompson        24.80        58       11.41          75   
    28                    Almeirim        52.84        87        9.17          40   
    29                      Dalvik        33.80       100        5.82          92   
    ..                         ...          ...       ...         ...         ...   
    514                 Kaitangata        70.92        63        4.76           0   
    515                   Gambiran        82.26        79        0.56          20   
    516                  Busselton        75.51        82       15.21           0   
    517                       Ukwa        73.98        96        6.11          56   
    518                  Grindavik        28.40        79        4.70           0   
    519                  Inhambane        72.23       100        4.88           0   
    520               Punta Arenas        46.40        75        8.05          75   
    521                     Hasaki        52.65        32       11.41          20   
    522                    Rikitea        80.28       100       18.23          88   
    523                     Atuona        81.68       100       17.00          92   
    524                    Ushuaia        46.40        70        9.17          40   
    525                  Busselton        75.51        82       15.21           0   
    526                New Norfolk        66.20        48        8.05          75   
    527                New Norfolk        66.20        48        8.05          75   
    528                       Miri        60.21        51        3.91           0   
    529                Provideniya         3.20        65       17.90          75   
    530                     Ixtapa        69.80        68        2.24           5   
    531                    Apatity        13.86        82        2.30          76   
    532                New Norfolk        66.20        48        8.05          75   
    533                  Upernavik         3.60        92        1.23          64   
    534                     Castro        56.34        98       12.37          92   
    535                 Chokurdakh       -26.78        42        3.13           8   
    536                    Salinas        55.38        87        5.82          20   
    537                  Road Town        73.40        94        9.17          20   
    538                     Yulara        93.20        12       17.22           0   
    539                   Souillac        50.81        81       17.22          75   
    540                   Hermanus        51.21        94        2.91           0   
    541                      Banes        77.00        73        5.82          20   
    542                     Avarua        84.20        70        9.17          20   
    543  Petropavlovsk-Kamchatskiy        23.00        41       17.90          44   
    
         latitude  
    0       11.00  
    1       55.74  
    2      -54.81  
    3       13.56  
    4       39.95  
    5       51.19  
    6        6.80  
    7       47.52  
    8       35.03  
    9      -23.12  
    10      77.48  
    11     -16.48  
    12     -46.19  
    13     -33.21  
    14      40.56  
    15      65.61  
    16     -42.48  
    17      60.79  
    18     -20.63  
    19     -23.58  
    20     -30.97  
    21     -20.07  
    22     -21.21  
    23     -22.45  
    24     -33.21  
    25      30.78  
    26      69.41  
    27      55.74  
    28      39.21  
    29      57.79  
    ..        ...  
    514    -46.28  
    515     -7.93  
    516    -33.64  
    517      5.47  
    518     63.84  
    519    -23.87  
    520    -53.16  
    521     35.73  
    522    -23.12  
    523     -9.80  
    524    -54.81  
    525    -33.64  
    526    -42.78  
    527    -42.78  
    528     10.31  
    529     64.42  
    530     20.71  
    531     67.57  
    532    -42.78  
    533     72.79  
    534    -42.48  
    535     70.62  
    536     36.67  
    537     18.42  
    538    -25.24  
    539     45.60  
    540    -34.42  
    541     20.96  
    542    -21.21  
    543     53.05  
    
    [544 rows x 6 columns]



```python
print(len(df))
```

    544



```python
plt.scatter(df["latitude"], df["temperature"], marker="o", facecolors="green", alpha=0.75)
plt.title("correlation between lat and temp")
plt.xlabel("Latitude")
plt.ylabel("Temperature(F)")
plt.grid()
plt.savefig("temp.png")
plt.show()


# the temperature is the higest when the latitude is near 0, and then the temp gets lower when the 
#latitude spread from 0 to two other sides. 
```


![png](output_6_0.png)



```python
plt.scatter(df["latitude"], df["humidity"], marker="o", facecolors="green", alpha=0.75)
plt.title("correlation between lat and humidity")
plt.xlabel("Latitude")
plt.ylabel("humidity")
plt.grid()
plt.savefig("humidity.png")
plt.show()



```


![png](output_7_0.png)



```python
plt.scatter(df["latitude"], df["wind_speed"], marker="o", facecolors="green", alpha=0.75)
plt.title("correlation between lat and wind speed")
plt.xlabel("Latitude")
plt.ylabel("Wind Speed")
plt.grid()
plt.savefig("wind_speed.png")
plt.show()

```


![png](output_8_0.png)



```python
plt.scatter(df["latitude"], df["Cloudiness"], marker="o", facecolors="green", alpha=0.75)
plt.title("correlation between lat and Cloudiness")
plt.xlabel("Latitude")
plt.ylabel("Cloudiness")
plt.grid()
plt.savefig("cloud.png")
plt.show()

```


![png](output_9_0.png)

